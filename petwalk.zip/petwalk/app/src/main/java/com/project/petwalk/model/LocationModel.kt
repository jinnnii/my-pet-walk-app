package com.project.petwalk.model

data class LocationModel (
    var latitude:Double,
    var longitude:Double,
    var time:Long
    )