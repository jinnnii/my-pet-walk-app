package com.project.petwalk.frag

import android.annotation.SuppressLint
import android.content.Context
import android.content.Context.LOCATION_SERVICE
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.content.ContextCompat.getSystemService
import androidx.core.content.ContextCompat.getSystemServiceName
import androidx.fragment.app.Fragment
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import com.google.common.collect.ObjectArrays
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.project.petwalk.R
import com.project.petwalk.databinding.FragmentFragWalkBinding
import com.project.petwalk.model.LocationModel


class FragWalk : Fragment() {
    lateinit var binding: FragmentFragWalkBinding

    //구글 맵
    lateinit var mMap:GoogleMap


    //현재위치
    lateinit var manager:LocationManager

    //파이어베이스
    val database:FirebaseDatabase = FirebaseDatabase.getInstance()
    val reference:DatabaseReference=database.getReference("locations")

    lateinit var key:String

    val locations = arrayListOf<LocationModel>()

    // 시작, 지도 그리기
    @SuppressLint("MissingPermission")
    private val callback = OnMapReadyCallback { googleMap ->
        mMap=googleMap

//        val location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
//        googleMap.addMarker(MarkerOptions().position(sydney).title("Marker in Sydney"))
         val cameraPosition = CameraPosition.Builder()
            .target(LatLng(locations[0].latitude!!, locations[0].longitude))
            .zoom(100F)
            .build()
        googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition))
    }

    private fun drawPath(){
//        for ( i in 0..locations.size-2){
//            val opsion = PolylineOptions()
//                .add(LatLng(locations[i].latitude, locations[i].longitude),LatLng(locations[i+1].latitude,locations[i+1].longitude))
//                .width(10F)
//                .color(Color.RED))
//
//        }
        val size= locations.size-1
        val start = LatLng(locations[size-1].latitude, locations[size-1].longitude)
        val end = LatLng(locations[size].latitude, locations[size].longitude)
        val options:PolylineOptions  = PolylineOptions().add(start).add(end).width(15F).color(Color.BLACK).geodesic(true);
        mMap.addPolyline(options)
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(end, 18F))

    }


    //실시간 위치
    private val listener:LocationListener = object:LocationListener{
        override fun onLocationChanged(location: Location) {
            sendLocation(key, location.latitude, location.longitude, location.time)
            locations.add(LocationModel(location.latitude, location.longitude, location.time))
            Log.d("pet","${location.latitude},${location.longitude}, ${location.time}")
        }

    }

    //파이어베이스에 위치 정보 저장
    private fun sendLocation(key:String, lat:Double, lon:Double, time:Long){
        val location= LocationModel( lat, lon, time)
        reference.child(key).child((locations.size).toString()).setValue(location)
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding= FragmentFragWalkBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        manager= activity?.getSystemService(LOCATION_SERVICE) as LocationManager

        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(callback)


        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ){
            if(it){

            }
            else{
                Log.d("pet","deny...")
            }
        }

        if(this.context?.let { ContextCompat.checkSelfPermission(it, "android.permission.ACCESS_FINE_LOCATION") } ==PackageManager.PERMISSION_GRANTED){
            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000L, 10f, listener)
            manager.removeUpdates(listener)
        }else{
            permissionLauncher.launch(("android.permission.ACCESS_FINE_LOCATION"))
        }

        binding.startBtn.setOnClickListener {
            key= reference.push().key!!

        }
    }
}